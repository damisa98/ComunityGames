<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/', 'JuegoController@index');

Route::get('/home', 'JuegoController@index')->name('home');

Route::group(['prefix'=>'Juego'], function(){

    Route::get('AllGames','JuegoController@juegos');
    Route::get('verUnJuego/{id}','JuegoController@getShow')->where('id','[0-9]+');
    Route::get('insertarJuego','JuegoController@insertarJuego')->middleware('auth');
    Route::get('IMGJuegos/{imagen}','JuegoController@getImage');
    Route::post('insertarJuego/Submit','JuegoController@save')->middleware('auth');
    Route::get('editarJuego/{id}','JuegoController@editarJuego')->where('id','[0-9]+')->middleware('auth');
    Route::post('editarJuego/submit/{id}','JuegoController@updateJuego')->where('id','[0-9]+')->middleware('auth');
    Route::get('borrarJuego/{id}','JuegoController@borrarJuego')->where('id', '[0-9]+')->middleware('auth');

});


Route::group(['prefix'=>'Usuario'], function(){

    Route::get('verUsuario/{id}','UserController@verUsuario')->where('id','[0-9]+')->middleware('auth');
    Route::get('editarUsuario/{id}','UserController@editarUsuario')->where('id','[0-9]+')->middleware('auth');
    Route::put('editar/submit/{id}','UserController@update')->where('id','[0-9]+')->middleware('auth');

});

Route::group(['prefix'=>'Juego/Oferta'], function(){

    Route::get('AllOffers','OfertaController@VerOfertas');
    Route::get('verUnaOferta/{id}','OfertaController@getShow')->where('id','[0-9]+');
    Route::get('insertarOferta','OfertaController@insertarOferta')->middleware('auth');
    Route::get('IMGJuegos/{imagen}','OfertaController@getImage');
    Route::post('insertarOferta/Submit','OfertaController@save')->middleware('auth');
    Route::get('editarOferta/{id}','OfertaController@editarOferta')->where('id','[0-9]+')->middleware('auth');
    Route::post('editarOferta/submit/{id}','OfertaController@updateOferta')->where('id','[0-9]+')->middleware('auth');
    Route::get('borrarOferta/{id}','OfertaController@borrarOferta')->where('id', '[0-9]+')->middleware('auth');

});

Route::group(['prefix'=>'Juego/Jugado'], function(){

    Route::get('insertarJugado/{id}','JugadoController@insertarJugado')->where('id','[0-9]+')->middleware('auth');
    Route::post('insertarJugadoValorar/{id}','JugadoController@insertarJugadoValorar')->where('id','[0-9]+')->middleware('auth');
    Route::get('editarJugado/{id}/{fav}','JugadoController@editarJugado')->where('id','[0-9]+')->where('fav','[0-9]+')->middleware('auth');
    Route::post('editarJuegoVal/{id}','JugadoController@editarJuegoVal')->where('id','[0-9]+')->middleware('auth');

});

Route::group(['prefix'=>'Juego/Jugado'], function(){

    Route::get('AllComentary','ComentarioController@verComentarios')->middleware('auth');
    Route::get('VerUnComentario/{id}','ComentarioController@getShow')->where('id','[0-9]+');
    Route::post('insertarComentario/submit/{id}','ComentarioController@insertarComentario')->middleware('auth');
    Route::get('borrarComentario/{id}','ComentarioController@borrarComentario')->where('id', '[0-9]+')->middleware('auth');
    Route::get('editarComentario/{id}/{juegoid}','ComentarioController@editarComentario')->where('id','[0-9]+')->where('juegoid','[0-9]+')->middleware('auth');
    Route::post('updateComentario/submit/{id}','ComentarioController@updateComentario')->where('id','[0-9]+')->middleware('auth');
    
});