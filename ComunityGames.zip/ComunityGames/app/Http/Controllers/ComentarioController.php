<?php

namespace App\Http\Controllers;

use App\Juego;
use App\Comentario;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;

class ComentarioController extends Controller
{
    
    public function verComentarios(){
        $juegos=Juego::all();
        $comentarios=Comentario::all();

        $cont=0;
        return view('Comentario.verComentarios',['cont'=>$cont,'comentarios'=>$comentarios,'juegos'=>$juegos]);
    }

    public function getShow($id){
        $juegos=Juego::findOrFail($id);
        $usuarioid=Auth::id();
        $usuariocoment = DB::table('juegos')
            ->select('comentarios.UsuarioID')
            ->join('comentarios','juegos.id','=','comentarios.JuegoID')
            ->join('users','users.id','=','comentarios.UsuarioID')
            ->where('juegos.id','=',$id)
            ->get();
        $comentarios = DB::table('juegos')
            ->select('comentarios.id','comentarios.Descripcion','users.Nick')
            ->join('comentarios','juegos.id','=','comentarios.JuegoID')
            ->join('users','users.id','=','comentarios.UsuarioID')
            ->where('juegos.id','=',$id)
            ->get();
        $existe = DB::table('juegos')
            ->join('comentarios','juegos.id','=','comentarios.JuegoID')
            ->where('juegos.id','=',$id)
            ->exists();
        return view('Comentario.VerUnComentario',['juegos'=>$juegos,'comentarios'=>$comentarios,'usuarioid'=>$usuarioid,'existe'=>$existe,'usuariocoment'=>$usuariocoment]);
    }

    public function editarComentario($id,$juegoid){
        $comentarios = Comentario::findOrFail($id);
        $juegos = Juego::find($juegoid);
        return view('Comentario.editarComentario',["comentarios"=>$comentarios,'juegos'=>$juegos]);
    }

    public function updateComentario(Request $request,$id){
        $comentario = Comentario::find($id);
        $comentario->Descripcion = $request->input('Descripcion');
        
        $comentario->save();
        return redirect()->action("ComentarioController@verComentarios");
    }

    
    public function insertarComentario($id,Request $request){
        $comentarios = new Comentario();
        $usuarioid=Auth::id();
        $comentarios->Descripcion = $request->input('Descripcion'); 
        $comentarios->UsuarioID = $usuarioid;
        $comentarios->JuegoID = $id;

        $comentarios->save();
        return redirect()->action("ComentarioController@getShow",$id)->with('status ', $id. ' creado correctamente');
    }

    public function borrarComentario($id){
        $comentarios = Comentario::findOrFail($id);
        $comentarios->delete();
        return redirect()->action('ComentarioController@verComentarios');
    }
}
