<?php

namespace App\Http\Controllers;

use App\Juego;
use App\Jugados;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;

class JugadoController extends Controller
{
    public function save(Request $request){
        $jugados = new Jugados();
        $jugados->nombre = $request->input('nombre'); 
        $jugados->genero = $request->input('genero');
        $jugados->desarrollador = $request->input('desarrollador');

        $jugados->save();
        return redirect()->action("JuegoController@juegos")->with('status ', $jugados->JuegoID. ' creado correctamente');
    }
}
