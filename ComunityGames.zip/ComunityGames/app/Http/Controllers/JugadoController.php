<?php

namespace App\Http\Controllers;

use App\Juego;
use App\Jugados;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;

class JugadoController extends Controller
{
    public function insertarJugado($id){
        $jugados = new Jugados();
        $usuarioid=Auth::id();
        $jugados->JuegoID = $id; 
        $jugados->UsuarioID = $usuarioid;
        $jugados->Valoración=0;
        $jugados->Favorito = true;

        $jugados->save();
        return redirect()->action("JuegoController@juegos")->with('status ', $jugados->JuegoID. ' creado correctamente');
    }
    public function insertarJugadoValorar(Request $request,$id){
        $jugados = new Jugados();
        $usuarioid=Auth::id();
        $jugados->JuegoID = $id; 
        $jugados->UsuarioID = $usuarioid;
        $jugados->Valoración=$request->input('Valoración');
        $jugados->Favorito = false;

        $jugados->save();
        return redirect()->action("JuegoController@juegos")->with('status ', $jugados->JuegoID. ' creado correctamente');
    }
    public function editarJugado($id,$fav){
        $usuarioid=Auth::id();
        $idJuego = DB::table('jugados')
            ->select('jugados.id')
            ->where('jugados.JuegoID','=',$id)
            ->where('jugados.UsuarioID','=',$usuarioid)
            ->first();
        
        $idJuego = intval(array($idJuego));
        $jugados = Jugados::find($idJuego); 
        $jugados->JuegoID = $id; 
        $jugados->UsuarioID = $usuarioid;
        $jugados->Valoración=0;
        $jugados->Favorito = (boolean)$fav;
        
        $jugados->save();
        return redirect()->action("JuegoController@juegos")->with('status ', $jugados->JuegoID. ' creado correctamente');
    }

    public function editarJuegoVal(Request $request,$id){
        $usuarioid=Auth::id();
        $idJuego = DB::table('jugados')
            ->select('jugados.id')
            ->where('jugados.JuegoID','=',$id)
            ->where('jugados.UsuarioID','=',$usuarioid)
            ->first();
        $fav = DB::table('jugados')
            ->join('juegos','juegos.id','=','jugados.JuegoID')
            ->join('users','users.id','=','jugados.UsuarioID')
            ->select('jugados.Favorito')
            ->where('jugados.JuegoID','=',$id)
            ->where('jugados.UsuarioID','=',$usuarioid)
            ->first();
        $idJuego = intval(array($idJuego));
        $jugados = Jugados::find($idJuego); 
        $jugados->JuegoID = $id; 
        $jugados->UsuarioID = $usuarioid;
        $jugados->Valoración=$request->input('Valoración');
        $jugados->Favorito = (boolean)$fav;
        
        $jugados->save();
        return redirect()->action("JuegoController@juegos")->with('status ', $jugados->JuegoID. ' creado correctamente');
    }
}
