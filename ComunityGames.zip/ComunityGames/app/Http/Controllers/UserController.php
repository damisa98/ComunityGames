<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }

    public function verUsuario($id){
        $usuario=User::findOrFail($id);
        return view('Usuario.verUsuario',['usuario'=>$usuario]);
    }


    public function editarUsuario($id){
        $usuario = User::findOrFail($id);
        return view('Usuario.editarUsuario',["usuario"=>$usuario]);
    }

    public function update(Request $request,$id){

        $validate = $this->validate($request, [
            'Nick' => 'required|string|max:100|unique:users,Nick,'.$id,
            'email' => 'required|string|email|max:30|unique:users,email,'.$id,
        ]);

        $usuario = User::find($id);
        $usuario->Nombre = $request->input('Nombre');
        $usuario->Apellidos = $request->input('Apellidos');
        $usuario->Nick = $request->input('Nick');
        $usuario->fecha = $request->input('fecha');
        $usuario->email = $request->input('email');
        $usuario->password = $request->input('password');
        $usuario->save();
        return redirect()->action("UserController@verUsuario",$usuario->id)->with('status', $usuario->Nick. ' actualizada correctamente');
    }
}
