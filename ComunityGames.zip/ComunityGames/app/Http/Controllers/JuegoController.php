<?php

namespace App\Http\Controllers;

use App\Juego;
use App\Jugado;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Support\Facades\Auth;

class JuegoController extends Controller
{
    public function index(){
        return view('home');
    }

    public function juegos(){
        $juegos=Juego::all(); 

        $recomendados=DB::table('juegos')
                ->select('juegos.id','juegos.nombre','juegos.Genero','juegos.Precio','juegos.Imagen',DB::raw('round(AVG(jugados.Valoración)) as avg'))
                ->groupBy('juegos.id','juegos.nombre','juegos.Genero','juegos.Precio','juegos.Imagen')
                ->leftJoin('jugados','juegos.id','=','jugados.JuegoID')
                ->orderBy('avg','DESC')
                ->get();
        
        $jugados=DB::table('juegos')
                ->select('juegos.id','juegos.nombre','juegos.Genero','juegos.Precio','juegos.Imagen','jugados.UsuarioID')
                ->join('jugados','juegos.id','=','jugados.JuegoID')
                ->join('users','users.id','=','jugados.UsuarioID')
                ->get();

        $favoritos=DB::table('juegos')
                ->select('juegos.id','juegos.nombre','juegos.Genero','juegos.Precio','juegos.Imagen','jugados.UsuarioID')
                ->join('jugados','juegos.id','=','jugados.JuegoID')
                ->join('users','users.id','=','jugados.UsuarioID')
                ->where('jugados.Favorito','=',1)
                ->get();

        $cont=0;
        return view('Juego.verJuegos',['cont'=>$cont,'juegos'=>$juegos,'recomendados'=>$recomendados,'jugados'=>$jugados,'favoritos'=>$favoritos]);
    }

    public function getShow($id){
        $juegos=Juego::findOrFail($id);
        $usuarioid=Auth::id();
        $existe = DB::table('ofertas')
            ->join('juegos','juegos.id','=','ofertas.JuegoID')
            ->where('juegos.id','=',$id)
            ->exists();
        $favorito = DB::table('jugados')
            ->join('juegos','juegos.id','=','jugados.JuegoID')
            ->join('users','users.id','=','jugados.UsuarioID')
            ->where('juegos.id','=',$id)
            ->where('jugados.Favorito','=','1')
            ->where('users.id','=',$usuarioid)
            ->exists();
        $jugado = DB::table('jugados')
            ->join('juegos','juegos.id','=','jugados.JuegoID')
            ->join('users','users.id','=','jugados.UsuarioID')
            ->where('juegos.id','=',$id)
            ->where('users.id','=',$usuarioid)
            ->exists();
        $valoracion = DB::table('jugados')
            ->join('juegos','juegos.id','=','jugados.JuegoID')
            ->join('users','users.id','=','jugados.UsuarioID')
            ->where('juegos.id','=',$id)
            ->where('jugados.valoración','>','0')
            ->where('users.id','=',$usuarioid)
            ->exists();
        return view('Juego.verUnJuego',['juegos'=>$juegos,'existe'=>$existe,'favorito'=>$favorito,'jugado'=>$jugado,'valoracion'=>$valoracion]);
    }

    public function editarJuego($id){
        $juegos = Juego::findOrFail($id);
        return view('Juego.editarJuego',["juegos"=>$juegos]);
    }

    public function insertarJuego(){
        return view('Juego.insertarJuego');
    }

    public function getImage($filename){
        $file = Storage::disk('juegos')->get($filename);             //necesario para que se muestre la imagen, crear discos virtuales y añadir en archivo gilesystems
        return new Response($file,500);
    }

    public function updateJuego(Request $request,$id){
        $juegos = Juego::find($id);
        $juegos->nombre = $request->input('nombre');
        $juegos->genero = $request->input('genero');
        $juegos->desarrollador = $request->input('desarrollador');
        $juegos->editor = $request->input('editor');
        $juegos->precio = $request->input('precio');
        $juegos->video = $request->input('video');
        $juegos->enlace = $request->input('enlace');
        

        $image_path = $request->file('imagen');                                  // Subir la imagen
        if($image_path){
            // Poner nombre único
            $image_path_name = time().$image_path->getClientOriginalName();

            // Guardar en la carpeta storage (storage/app/users)
            Storage::disk('juegos')->put($image_path_name, File::get($image_path));

            // Seteo el nombre de la imagen en el objeto
            $juegos->imagen = $image_path_name;                               // aquí se almacena en el atributo imagen
        }
        $juegos->save();
        return redirect()->action("JuegoController@getShow",$juegos->id)->with('status ', $juegos->nombre. ' actualizado correctamente');
    }

    
    public function save(Request $request){
        $juegos = new Juego();
        $juegos->nombre = $request->input('nombre'); 
        $juegos->genero = $request->input('genero');
        $juegos->desarrollador = $request->input('desarrollador');
        $juegos->editor = $request->input('editor');
        $juegos->precio = $request->input('precio');
        $juegos->video = $request->input('video');
        $juegos->enlace = $request->input('enlace');

        $image_path = $request->file('imagen');                                  // Subir la imagen
        if($image_path){
            // Poner nombre único
            $image_path_name = time().$image_path->getClientOriginalName();

            // Guardar en la carpeta storage (storage/app/users)
            Storage::disk('juegos')->put($image_path_name, File::get($image_path));

            // Seteo el nombre de la imagen en el objeto
            $juegos->imagen = $image_path_name;                               // aquí se almacena en el atributo imagen
        }

        $juegos->save();
        return redirect()->action("JuegoController@getShow",$juegos->id)->with('status ', $juegos->nombre. ' creado correctamente');
    }

    public function borrarJuego($id){
        $juegos = Juego::findOrFail($id);
        $juegos->delete();
        return redirect()->action('JuegoController@juegos')->with('status ' , $juegos->nombre .' borrado correctamente');
    }

}
