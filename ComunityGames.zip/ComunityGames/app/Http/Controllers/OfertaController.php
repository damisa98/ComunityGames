<?php

namespace App\Http\Controllers;

use App\Juego;
use App\Oferta;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;

class OfertaController extends Controller
{
    public function verOfertas(){
        $ofertas=DB::table('juegos')
            ->select('ofertas.id','juegos.nombre','juegos.Genero','juegos.Precio','juegos.Imagen','juegos.Enlace','ofertas.PrecioOferta')
            ->join('ofertas','juegos.id','=','ofertas.JuegoID')
            ->get();
   
        $cont=0;
        return view('Oferta.VerOfertas',['cont'=>$cont,'ofertas'=>$ofertas]);
    }

    public function getShow($id){
        $juegos=DB::table('juegos')
            ->select('ofertas.id','juegos.nombre','juegos.Genero','juegos.Desarrollador','juegos.Editor','juegos.Precio','juegos.Imagen','juegos.Video','juegos.Enlace','ofertas.PrecioOferta','ofertas.JuegoID')
            ->join('ofertas','juegos.id','=','ofertas.JuegoID')
            ->where('ofertas.id','=',$id)
            ->first();
        return view('Oferta.verUnaOferta',['juegos'=>$juegos]);
    }

    public function editarOferta($id){
        $ofertas = Oferta::findOrFail($id);
        $juegos= Juego::all();
        return view('Oferta.editarOferta',["ofertas"=>$ofertas,"juegos"=>$juegos]);
    }

    public function insertarOferta(){
        $juegos=Juego::all(); 
        return view('Oferta.insertarOferta',["juegos"=>$juegos]);
    }

    public function getImage($filename){
        $file = Storage::disk('juegos')->get($filename);             //necesario para que se muestre la imagen, crear discos virtuales y añadir en archivo gilesystems
        return new Response($file,500);
    }

    public function updateOferta(Request $request,$id){
        $ofertas = Oferta::find($id);
        $ofertas->JuegoID = $request->get('JuegoID'); 
        $ofertas->PrecioOferta = $request->input('PrecioOferta');
        
        $ofertas->save();
        return redirect()->action("OfertaController@getShow",$ofertas->id)->with('status ', $ofertas->JuegoID. ' actualizado correctamente');
    }

    
    public function save(Request $request){
        $ofertas = new Oferta();
        $ofertas->JuegoID = $request->get('JuegoID'); 
        $ofertas->PrecioOferta = $request->input('PrecioOferta');
        

        $ofertas->save();
        return redirect()->action("OfertaController@getShow",$ofertas->id)->with('status ', $ofertas->JuegoID. ' creado correctamente');
    }

    public function borrarOferta($id){
        $ofertas = Oferta::findOrFail($id);
        $ofertas->delete();
        return redirect()->action('OfertaController@VerOfertas')->with('status ' , $ofertas->JuegoID .' borrado correctamente');
    }
}
