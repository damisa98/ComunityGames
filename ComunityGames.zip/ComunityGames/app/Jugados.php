<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jugados extends Model
{
    protected $table = 'jugados';

    protected $fillable = [
        'UsuarioID','JuegoID','Favorito','Valoración'
    ];

    public function User(){
        return $this->hasMany('App\User')->orderBy('id','desc');
    }

    public function Juego(){
        return $this->hasMany('App\Juego')->orderBy('id','desc');
    }
}
