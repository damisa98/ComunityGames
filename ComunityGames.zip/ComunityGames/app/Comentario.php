<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comentario extends Model
{

    protected $table = 'comentarios';

    protected $fillable = [
        'UsuarioID','JuegoID','Descripcion'
    ];

    public function User(){
        return $this->hasMany('App\User')->orderBy('id','desc');
    }

    public function Juego(){
        return $this->hasMany('App\Juego')->orderBy('id','desc');
    }

}
