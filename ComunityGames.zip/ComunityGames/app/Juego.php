<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Juego extends Model
{
    protected $table = 'juegos';

    protected $fillable = [
        'Nombre','Genero','Desarrollador','Editor','Precio','Imagen','Video','Enlace'
    ];

    public function Comentario(){
        return $this->belongsTo('App\Comentario', 'ComentarioID');  //usuarioId es la clave foránea en la tabla Juego
    }

    public function Oferta(){
        return $this->belongsTo('App\Oferta', 'JuegosID');  //usuarioId es la clave foránea en la tabla Juego
    }

}
