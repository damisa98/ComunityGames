@extends('index')
@section('content')
    <div class="container-fluid mb-5"  style="height: 800px">
        <div class="row mt-3">
            <div class="col-12 ">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" style="color:black" id="home-tab" data-toggle="tab" href="#VerJuegos" role="tab" aria-controls="VerJuegos" aria-selected="true">Ver Juegos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Recomendados" role="tab" aria-controls="Recomendados" aria-selected="false">Recomendados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Juegados" role="tab" aria-controls="Juegados" aria-selected="false">Juegados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Favoritos" role="tab" aria-controls="Favoritos" aria-selected="false">Favoritos</a>
                    </li>
                    @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
                        @auth
                            @if(auth()->user()->Rol=='admin')
                            <li class="nav-item">
                                <a href="{{action('JuegoController@insertarJuego')}}"><button type="button" class="btn btn-dark ">Insertar Juego</button></a>
                            </li>
                            @endif
                        @endauth
                    @endif
                </ul>


                <!-- VerJuegos -->

                <div class="tab-content mb-5 " id="myTabContent">

                    <div class="tab-pane fade show active pb-5 mb-5" id="VerJuegos" role="tabpanel" aria-labelledby="VerJuegos-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver Todos los Juegos</h3>

                                @if (session()->has('status'))
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8 justify-content-between" >
                                        <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            {{session('status')}}
                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                @endif

                                <div class="row" style="min-height:400px">
                                    @foreach ($juegos as $juego)
                                        <div class="col-md-3 col-sm-6 mb-4 text-center">
                                            <a href="{{ action('JuegoController@getShow', ['id' => $juego->id]) }}" style="text-decoration: none; color:black;">
                                                <div class="card bg-info">
                                                    <img class="card-img-top" src="{{action('JuegoController@getImage',['filename'=>$juego->Imagen])}}" alt="Juego {{$juego->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                                    <div class="card-body">
                                                        <h5 class="card-title ">{{$juego->nombre}}</h5>
                                                        <p>Genero: {{$juego->Genero}}</p>
                                                        <p>Precio: {{$juego->Precio}} €</p>
                                                    </div>
                                                </div>
                                            </a><span class="text-secondary">{{$cont++}}</span>
                                        </div>
                                        

                                    @endforeach
                                    @if($cont==0)
                                    <div class="col-md-3"></div>
                                    <div class="col-md-6 justify-content-between" >
                                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                            No hay juegos registrados
                                        </div>
                                    </div>
                                    <div class="col-md-3"></div>
                                    @endif
                                    <span class="text-secondary">{{$cont=0}}</span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>
                            </div>
                        </div>
                    </div>


                        <!-- Recomendados -->

                    <div class="tab-pane fade pb-5 mb-5" id="Recomendados" role="tabpanel" aria-labelledby="Recomendados-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Recomendados</h3>

                                @if (session()->has('status'))
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        {{session('status')}}
                                    </div>
                                @endif
                                <div class="row" style="min-height:400px">
                                    @foreach ($recomendados as $recomendado)
                                        <div class="col-md-3 col-sm-6 mb-4 text-center">
                                            <a href="{{ action('JuegoController@getShow', ['id' => $recomendado->id]) }}" style="text-decoration: none; color:black;">
                                                    <div class="card bg-info">
                                                        <img class="card-img-top" src="{{action('JuegoController@getImage',['filename'=>$recomendado->Imagen])}}" alt="Juego Recomendado {{$recomendado->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                                        <div class="card-body">
                                                            <h5 class="card-title ">{{$recomendado->nombre}}</h5>
                                                            <p>Genero: {{$recomendado->Genero}}</p>
                                                            <p>Precio: {{$recomendado->Precio}} €</p>
                                                        </div>
                                                    </div>
                                            </a><span class="text-secondary">{{$cont++}}</span>
                                        </div>

                                        @endforeach
                                        @if($cont==0)
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6 justify-content-between" >
                                            <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                                No hay juegos recomendados registrados
                                            </div>
                                        </div>
                                        <div class="col-md-3"></div>
                                        @endif
                                        <span class="text-secondary">{{$cont=0}}</span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>

                            </div>
                        </div>
                    </div>

                        <!-- Jugados -->

                    <div class="tab-pane fade pb-5 mb-5" id="Juegados" role="tabpanel" aria-labelledby="Juegados-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Jugados</h3>
                                @if (session()->has('status'))
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        {{session('status')}}
                                    </div>
                                @endif
                                <div class="row"  style="min-height:400px">
                                    @foreach ($jugados as $jugado)
                                        @if(Route::has('login'))
                                            @auth
                                                @if($jugado->UsuarioID==auth()->user()->id)

                                                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                                                        <a href="{{ action('JuegoController@getShow', ['id' => $jugado->id]) }}" style="text-decoration: none; color:black;">
                                                            <div class="card bg-info">
                                                                <img class="card-img-top" src="{{action('JuegoController@getImage',['filename'=>$jugado->Imagen])}}" alt="Juego jugado {{$jugado->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                                                <div class="card-body">
                                                                <h5 class="card-title ">{{$jugado->nombre}}</h5>
                                                                    <p>Genero: {{$jugado->Genero}}</p>
                                                                    <p>Precio: {{$jugado->Precio}} €</p>
                                                                </div>
                                                            </div>
                                                        </a><span class="text-secondary">{{$cont++}}</span>
                                                    </div>
                                                @endif
                                            @endauth
                                        @endif
                                    @endforeach
                                    @if($cont==0)
                                    <div class="col-md-3"></div>
                                    <div class="col-md-6 justify-content-between" >
                                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                            No hay juegos jugados registrados
                                        </div>
                                    </div>
                                    <div class="col-md-3"></div>
                                    @endif
                                    <span class="text-secondary">{{$cont=0}}</span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>


                            </div>
                        </div>
                    </div>

                        <!-- Favoritos -->

                    <div class="tab-pane fade pb-5 mb-5" id="Favoritos" role="tabpanel" aria-labelledby="Favoritos-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Favoritos</h3>

                                @if (session()->has('status'))
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        {{session('status')}}
                                    </div>
                                @endif
                                <div class="row" style="min-height:400px">
                                    @foreach ($favoritos as $favorito)
                                        @if(Route::has('login'))
                                            @auth
                                                @if($jugado->UsuarioID==auth()->user()->id)

                                                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                                                        <a href="{{ action('JuegoController@getShow', ['id' => $favorito->id]) }}" style="text-decoration: none; color:black;">
                                                                <div class="card bg-info">
                                                                    <img class="card-img-top" src="{{action('JuegoController@getImage',['filename'=>$favorito->Imagen])}}" alt="Juego en favorito {{$favorito->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                                                    <div class="card-body">
                                                                        <h5 class="card-title ">{{$favorito->nombre}}</h5>
                                                                        <p>Genero: {{$favorito->Genero}}</p>
                                                                        <p>Precio: {{$favorito->Precio}} €</p>
                                                                    </div>
                                                                </div>
                                                        </a><span class="text-secondary">{{$cont++}}</span>
                                                    </div>
                                                @endif
                                            @endauth
                                        @endif
                                    @endforeach
                                    @if($cont==0)
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6 justify-content-between" >
                                            <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                                No hay juegos en favoritos
                                            </div>
                                        </div>
                                        <div class="col-md-3"></div>
                                    @endif
                                    <span class="text-secondary">{{$cont=0}}</span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

@stop