@extends('index')
@section('content')

<div class="container-fluid mb-5">
    <div class="row">
        <p class="col mt-3 text-warning"><a href="{{ URL::previous() }}"><button type="button" class="btn btn-warning text-white"><i class="fas fa-angle-double-left"></i></button></a></p>
    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
        <h3 class="text-center mb-5 text-info">Añadir Juego</h3>
        <form action="{{action('JuegoController@save')}}" method="POST" enctype="multipart/form-data" style="height: 600px">
        {{csrf_field()}}
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nombre">{{ __('Nombre:') }}</label>
                    <input type="text" class="form-control" id="nombre" class="form-control @error('nombre') is-invalid @enderror" name="nombre" placeholder="Nombre del juego" autocomplete="nombre" autofocus required>
                    @error('Nombre')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="genero">{{ __('Genero:') }}</label>
                    <input type="text" class="form-control" id="genero" class="form-control @error('genero') is-invalid @enderror" name="genero" autocomplete="genero" autofocus placeholder="Genero del juego" required>
                    @error('Genero')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="desarrollador">Desarrollador:</label>
                    <input type="text" class="form-control" id="desarrollador" class="form-control @error('desarrollador') is-invalid @enderror" name="desarrollador" autocomplete="desarrollador" placeholder="Desarrollador del juego"required>
                    @error('Desarrollador')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="editor">Editor:</label>
                    <input type="text" class="form-control" id="editor" class="form-control @error('editor') is-invalid @enderror" name="editor" autocomplete="editor" placeholder="Editor del juego"required>
                    @error('Editor')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Precio:</label>
                    <input type="number" class="form-control" id="precio" class="form-control @error('precio') is-invalid @enderror" name="precio" autocomplete="precio"placeholder="Precio del juego" required>
                    @error('precio')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label>Video:</label>
                    <input type="text" class="form-control" id="video" class="form-control @error('video') is-invalid @enderror" name="video" autocomplete="video" placeholder="Link del juego" required>
                    @error('colores')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Imagen:</label>
                    <input type="file" class="form-control" id="imagen" class="form-control @error('imagen') is-invalid @enderror" name="imagen" autocomplete="imagen" >
                    @error('imagen')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label>Enlace de Compra:</label>
                    <input type="text" class="form-control" id="enlace" class="form-control @error('enlace') is-invalid @enderror" name="enlace" autocomplete="enlace" >
                    @error('enlace')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Añadir Juego</button>
            </div>
        </form>
    </div>
    <div class="col-md-2"></div>
    </div>
</div>

@stop