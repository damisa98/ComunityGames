@extends('index')
@section('content')
    <div class="container-fluid" >

        @if (session()->has('status'))
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    {{session('status')}}
                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        @endif

        <div class="row">
            <p class="col mt-3 text-warning"><a href="{{ URL::previous() }}"><button type="button" class="btn btn-dark text-white"><i class="fas fa-angle-double-left">Atras</i></button></a></p>
            @if(Route::has('login'))
                @auth
                    @if($jugado!='false')
                        <p class="col mt-3 text-warning"><a href="{{action('JugadoController@insertarJugado',['id'=>$juegos->id])}}"><button type="button" class="btn btn-dark text-white"><i class="fas fa-heart"> Insertar a Favorito</i></button></a></p>
                        <div class="form-group col-md-4">
                            <form action="{{action('JugadoController@insertarJugadoValorar',['id'=>$juegos->id])}}" method="POST" enctype="multipart/form-data" style="height: 600px">
                                {{csrf_field()}}    
                                <label>Valorar:</label>
                                <input type="number" class="form-control" id="Valoración" class="form-control @error('Valoración') is-invalid @enderror" name="Valoración" value="0" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                @error('Valoración')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                @enderror
                                <div class="form-row d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn btn-info">Insertar Valoración</button>
                                </div>
                            </form>
                        </div>
                    @else
                        @if($favorito!='false')
                            <p class="col mt-3 text-warning"><a href="{{action('JugadoController@editarJugado',['id'=>$juegos->id,'fav'=>1])}}"><button type="button" class="btn btn-dark text-white"><i class="fas fa-heart"> Añadir a Favorito</i></button></a></p>
                        @else
                            <p class="col mt-3 text-warning"><a href="{{action('JugadoController@editarJugado',['id'=>$juegos->id,'fav'=>0])}}"><button type="button" class="btn btn-dark text-white"><i class="far fa-heart"> Quitar de Favorito</i></button></a></p>
                        @endif
                        @if($valoracion!='false')
                            <div class="form-group col-md-4">
                                <form action="{{action('JugadoController@editarJuegoVal',['id'=>$juegos->id])}}" method="POST" enctype="multipart/form-data" >
                                    {{csrf_field()}}    
                                    <label>Valorar:</label>
                                    <input type="number" class="form-control" id="Valoración" class="form-control @error('Valoración') is-invalid @enderror" name="Valoración" value="{{$juegos->Enlace}}" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                    @error('Valoración')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                    @enderror
                                    <div class="form-row d-flex justify-content-center">
                                        <button type="submit" name="submit" class="btn btn-info">Añadir Valoración</button>
                                    </div>
                                </form>
                            </div>
                        @else
                            <div class="form-group col-md-4">
                                <form action="{{action('JugadoController@editarJuegoVal',['id'=>$juegos->id])}}" method="POST" enctype="multipart/form-data" style="height: 600px">
                                    {{csrf_field()}}    
                                    <label>Editar Valoración:</label>
                                    <input type="number" class="form-control" id="Valoración" class="form-control @error('Valoración') is-invalid @enderror" name="Valoración" value="{{$juegos->Enlace}}" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                    @error('Valoración')
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                    @enderror
                                    <div class="form-row d-flex justify-content-center">
                                        <button type="submit" name="submit" class="btn btn-info">Editar Valoración</button>
                                    </div>
                                </form>
                            </div>
                        @endif
                    @endif
                @endauth
            @endif
        </div>

        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
        <div class="col-md-7 mt-2 mb-3 pb-5 mr-2" max-height="700px">
            <img src="{{action('JuegoController@getImage',['filename'=>$juegos->Imagen])}}" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
        </div>

        <div class="col-md-3 mb-5 ml-4 pb-5 text-center">
            <table class="table ">
                <thead >
                    <tr>
                        <th scope="col" colspan="2"><h3 class="pb-42pt-2 text-secondary">{{$juegos->nombre}}</h3></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="table-secondary">
                        <td>Genero:</td>
                        <td>{{$juegos->Genero}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Desarrollador:</td>
                        <td>{{$juegos->Desarrollador}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Editor:</td>
                        <td>{{$juegos->Editor}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio:</td>
                        <td>{{$juegos->Precio}} €</td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Gameplay:</td>
                        <td><a class="nav-link text-warning" href="{{$juegos->Video}}"><i class="fab fa-youtube" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Enlace:</td>
                        <td><a class="nav-link text-warning" href="{{$juegos->Enlace}}"><i class="fab fa-steam" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr>
                        <td>
                            @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
                                @auth
                                    @if(auth()->user()->Rol=='admin')
                                        <a href="{{ action('JuegoController@editarJuego', ['id' => $juegos->id] ) }}" class="btn btn-warning">Modificar juego</a>
                                    @endif
                                @endauth
                            @endif
                        </td>
                        <td>
                            @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
                                @auth
                                    @if(auth()->user()->Rol=='admin')
                                        @if($existe!='false')
                                            <a href="{{ action('JuegoController@borrarJuego', ['id' => $juegos->id] ) }}" class="btn btn-danger">Eliminar juego</a>
                                        @else
                                            <a href="#" class="btn btn-danger">Oferta Existente</a>
                                        @endif
                                    @endif
                                @endauth
                            @endif
                            
                        </td>
                    </tr>

                </tbody>
            </table>

        </div>
    </div>
@stop