@extends('index')
@section('content')

<div class="container mb-5">
    <h3 class="text-center mt-5 mb-5 text-info">Editar Juego</h3>
        <form action="{{action('JuegoController@updateJuego',['id'=>$juegos->id])}}" method="POST" enctype="multipart/form-data" style="height: 600px">

            {{csrf_field()}}
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nombre">{{ __('Nombre:') }}</label>
                    <input type="text" class="form-control" id="nombre" class="form-control @error('nombre') is-invalid @enderror" name="nombre" value="{{$juegos->nombre}}"  placeholder="Nombre del juego" autocomplete="nombre" autofocus required>
                    @error('nombre')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="genero">{{ __('Genero:') }}</label>
                    <input type="text" class="form-control" id="genero" class="form-control @error('genero') is-invalid @enderror" name="genero" value="{{$juegos->Genero}}"  autocomplete="genero" autofocus placeholder="Genero del juego" required>
                    @error('Genero')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="desarrollador">Desarrollador:</label>
                    <input type="text" class="form-control" id="desarrollador" class="form-control @error('desarrollador') is-invalid @enderror" name="desarrollador" value="{{$juegos->Desarrollador}}"  autocomplete="desarrollador" placeholder="Desarrollador del juego"required>
                    @error('Desarrollador')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label for="editor">Editor:</label>
                    <input type="text" class="form-control" id="editor" class="form-control @error('editor') is-invalid @enderror" name="editor" value="{{$juegos->Editor}}"  autocomplete="editor" placeholder="Editor del juego"required>
                    @error('Editor')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label>Precio:</label>
                    <input type="text" class="form-control" id="precio" class="form-control @error('precio') is-invalid @enderror" name="precio" value="{{$juegos->Precio}}"  autocomplete="precio"placeholder="Precio del juego" required>
                    @error('precio')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>Imagen:</label>
                    <input type="file" class="form-control" id="imagen" class="form-control @error('imagen') is-invalid @enderror" name="imagen" value="{{$juegos->Imagen}}"   autocomplete="imagen" >
                    @error('imagen')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>

                <div class="form-group col-md-4">
                    <label>Video:</label>
                    <input type="text" class="form-control" id="video" class="form-control @error('video') is-invalid @enderror" name="video" value="{{$juegos->Video}}" autocomplete="video" placeholder="Link del juego" required>
                    @error('video')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-4">
                    <label>Enlace del juego:</label>
                    <input type="text" class="form-control" id="enlace" class="form-control @error('enlace') is-invalid @enderror" name="enlace" value="{{$juegos->Enlace}}" autocomplete="enlace" placeholder="enlace del juego" required>
                    @error('enlace')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Modificar Juego</button>
            </div>
        </form>
</div>

@stop