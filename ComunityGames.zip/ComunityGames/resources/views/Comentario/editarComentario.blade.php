@extends('index')
@section('content')
    <div class="container-fluid" >

        @if (session()->has('status'))
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    {{session('status')}}
                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        @endif

        <div class="row">
            <div class="col-md-4 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <img src="{{action('JuegoController@getImage',['filename'=>$juegos->Imagen])}}" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
            </div>
            <div class="col-md-6 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <form action="{{action('ComentarioController@updateComentario',['id'=>$comentarios->id])}}" method="POST" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="comentario">{{ __('Comentario:') }}</label>
                            <textarea class="form-control @error('Descripcion') is-invalid @enderror" id="Descripcion" rows="7" name="Descripcion" placeholder="Comentario del juego" autocomplete="Descripcion" autofocus required>{{$comentarios->Descripcion}}</textarea>
                            @error('Descripcion')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                            @enderror
                            <button type="submit" name="submit" class="btn btn-info">Añadir Comentario</button>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
    </div>
@stop