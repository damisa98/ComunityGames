@extends('index')
@section('content')
    <div class="row">
        <div class="col-md-12">

            <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver Comentarios de los Juegos</h3>

            @if (session()->has('status'))
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8 justify-content-between" >
                    <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        {{session('status')}}
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            @endif

            <div class="row" style="min-height:400px">
                @foreach ($juegos as $juego)
                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                        <a href="{{ action('ComentarioController@getShow', ['id' => $juego->id]) }}" style="text-decoration: none; color:black;">
                            <div class="card bg-info">
                                <img class="card-img-top" src="{{action('OfertaController@getImage',['filename'=>$juego->Imagen])}}" alt="Juego {{$juego->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                <div class="card-body">
                                    <h5 class="card-title ">{{$juego->nombre}}</h5>
                                    <p>Genero: {{$juego->Genero}}</p>
                                </div>
                            </div>
                        </a><span class="text-secondary">{{$cont++}}</span>
                    </div>
                    

                @endforeach
                
            </div>
        </div>
    </div>
    <div class="row mb-5 mt-2">
    <div class="col-md-1 mt-2 mb-3 pb-5"></div>
@stop