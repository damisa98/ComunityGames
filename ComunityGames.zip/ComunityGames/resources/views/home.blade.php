@extends('index')
@section('content')
    <div class="container-fluid mb-5">
        <div class="row mt-2 mb-5">
            <div class="col-lg-1"></div>
            <div class="col-lg-4 mt-5">
                <h2 class="mt-5">¿Qué es ComunityGames? </h2>
                <p class="mt-3">ComunityGames es una página web la cual puedas ver los distintos juegos tanto los existentes como los que vienen por llegar.</p>

                <p class="mt-3">Támbien tiene un apartado de ofertas la cual puedes mirar muchos de los juegos que estaran en ofertas en ese momento. No te pierdas ninguna!!</p>

                <p class="mt-3">¿ No tienes amigos con los que jugar a tu juego favorito ?, mira en nuestros foros y busca a gente dispuesta a jugar contigo, no te lo pierdas!!<i class="fas fa-gamepad"></i></p>
            </div>
            <div class="col-lg-1"></div>

            <div class="col-lg-5 mt-5 mb-5" >

                <img src="img/Bienvenidos.jpg" width="1200px" alt="ComunityGames" class="img-fluid rounded mx-auto d-block">

            </div>
        </div>
    </div>
@stop