<footer class="bg-success p-4 text-center mt-5 fixed-bottom row d-flex justify-content-center" >
    <div class="col md-4"> <a class="text-dark" href="https://www.facebook.com/Comunity-Games-1463807193851777/"><i class="fab fa-facebook" style="font-size:30px"></i></a></div>
    <div class="col-sm-12 col-md-4 "><span class="pie text-dark">&copy; Comunity Games <i class="fas fa-gamepad"></i></span></div>
    <div class="col md-4"><a class="text-dark" href="https://www.youtube.com/channel/UCKMk5_9po6s027SmO5Ji8IA"><i class="fab fa-youtube" style="font-size:30px"></i></a></div>
</footer>
