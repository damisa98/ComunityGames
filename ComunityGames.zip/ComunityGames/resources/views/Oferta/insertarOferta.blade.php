@extends('index')
@section('content')

<div class="container-fluid mb-5">
    <div class="row">
        <p class="col mt-3 text-warning"><a href="{{ URL::previous() }}"><button type="button" class="btn btn-warning text-white"><i class="fas fa-angle-double-left"></i></button></a></p>
    </div>

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
        <h3 class="text-center mb-5 text-info">Añadir Oferta</h3>
        <form action="{{action('OfertaController@save')}}" method="POST" enctype="multipart/form-data" style="height: 600px">
        {{csrf_field()}}
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="JuegoID">{{ __('Juego:') }}</label>
                    <select class="form-control" id="JuegoID" class="form-control @error('JuegoID') is-invalid @enderror" name="JuegoID" value="{{ old('JuegoID') }}"  autocomplete="JuegoID" required>
                        @foreach ($juegos as $juego)
                            <option value="{{$juego->id}}">{{$juego->nombre}}</option>
                        @endforeach
                    </select>
                    @error('JuegoID')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="PrecioOferta">{{ __('Precio Oferta:') }}</label>
                    <input type="number" class="form-control" id="PrecioOferta" class="form-control @error('PrecioOferta') is-invalid @enderror" name="PrecioOferta" autocomplete="PrecioOferta" autofocus placeholder="PrecioOferta" required>
                    @error('PrecioOferta')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="fechaIni">{{ __('Fecha Inicio:') }}</label>
                    <input type="date" class="form-control" id="fechaIni" name="fechaIni">
                    @error('fechaIni')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="fechaFin">{{ __('Fecha Fin:') }}</label>
                    <input type="date" class="form-control" id="fechaFin" name="fechaFin">
                    @error('fechaFin')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Añadir Oferta</button>
            </div>
        </form>
    </div>
    <div class="col-md-2"></div>
    </div>
</div>

@stop