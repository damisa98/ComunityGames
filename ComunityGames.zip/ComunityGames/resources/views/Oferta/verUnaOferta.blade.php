@extends('index')
@section('content')
    <div class="container-fluid" >

        @if (session()->has('status'))
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    {{session('status')}}
                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        @endif

        <div class="row">
            <p class="col mt-3 text-warning"><a href="{{ URL::previous() }}"><button type="button" class="btn btn-warning text-white"><i class="fas fa-angle-double-left"></i></button></a></p>
        </div>

        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
        <div class="col-md-7 mt-2 mb-3 pb-5 mr-2" max-height="700px">
            <img src="{{action('OfertaController@getImage',['filename'=>$juegos->Imagen])}}" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
        </div>

        <div class="col-md-3 mb-5 ml-4 pb-5 text-center">
            <table class="table ">
                <thead >
                    <tr>
                        <th scope="col" colspan="2"><h3 class="pb-42pt-2 text-secondary">{{$juegos->nombre}}</h3></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="table-secondary">
                        <td>Genero:</td>
                        <td>{{$juegos->Genero}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Desarrollador:</td>
                        <td>{{$juegos->Desarrollador}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Editor:</td>
                        <td>{{$juegos->Editor}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio Original:</td>
                        <td><strike>{{$juegos->Precio}} €</strike></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio Oferta:</td>
                        <td>{{$juegos->PrecioOferta}} €</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Fecha Inicio:</td>
                        <td>{{$juegos->fechaIni}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Fecha Fin:</td>
                        <td>{{$juegos->fechaFin}}</td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Gameplay:</td>
                        <td><a class="nav-link text-warning" href="{{$juegos->Video}}"><i class="fab fa-youtube" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Enlace:</td>
                        <td><a class="nav-link text-warning" href="{{$juegos->Enlace}}"><i class="fab fa-steam" style="font-size:30px"></i></a></td>
                    </tr>

                    <tr>
                        <td>
                            @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
                                @auth
                                    @if(auth()->user()->Rol=='admin')
                                        <a href="{{ action('OfertaController@editarOferta', ['id' => $juegos->id] ) }}" class="btn btn-warning">Modificar oferta</a>
                                    @endif
                                @endauth
                            @endif
                        </td>
                        <td>
                            @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
                                @auth
                                    @if(auth()->user()->Rol=='admin')
                                        <a href="{{ action('OfertaController@borrarOferta', ['id' => $juegos->id] ) }}" class="btn btn-danger">Eliminar oferta</a>
                                    @endif
                                @endauth
                            @endif
                        </td>
                    </tr>

                </tbody>
            </table>

        </div>
    </div>
@stop