@extends('index')
@section('content')

<div class="container mb-5">
    <h3 class="text-center mt-5 mb-5 text-info">Editar Juego</h3>
        <form action="{{action('OfertaController@updateOferta',['id'=>$ofertas->id])}}" method="POST" enctype="multipart/form-data" style="height: 600px">

            {{csrf_field()}}
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="JuegoID">{{ __('Juego:') }}</label>
                    <select class="form-control" id="JuegoID" class="form-control @error('JuegoID') is-invalid @enderror" name="JuegoID" value="{{$ofertas->JuegoID}}"  autocomplete="JuegoID" required>
                        @foreach ($juegos as $juego)
                            <option value="{{$juego->id}}">{{$juego->nombre}}</option>
                        @endforeach
                    </select>
                    @error('JuegoID')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
                <div class="form-group col-md-6">
                    <label for="PrecioOferta">{{ __('Precio Oferta:') }}</label>
                    <input type="number" class="form-control" id="PrecioOferta" class="form-control @error('PrecioOferta') is-invalid @enderror" name="PrecioOferta" value="{{$ofertas->PrecioOferta}}" autocomplete="PrecioOferta" autofocus placeholder="PrecioOferta" required>
                    @error('PrecioOferta')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                    @enderror
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Modificar Juego</button>
            </div>
        </form>
</div>

@stop