@extends('index')
@section('content')
    <div class="row">
        @if(Route::has('login'))          <!--Si no está logueado ni es admin no muestra el botón-->
            @auth
                @if(auth()->user()->Rol=='admin')
                <div class="col-md-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link" href="{{action('OfertaController@insertarOferta')}}"><button type="button" class="btn btn-dark ">Insertar Oferta</button></a>
                        </li>
                    </ul>
                </div>
                @endif
            @endauth
        @endif
        <div class="col-md-12">

            <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver las ofertas de los Juegos</h3>

            @if (session()->has('status'))
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8 justify-content-between" >
                    <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        {{session('status')}}
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            @endif

            <div class="row" style="min-height:400px">
                @foreach ($ofertas as $juego)
                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                        <a href="{{ action('OfertaController@getShow', ['id' => $juego->id]) }}" style="text-decoration: none; color:black;">
                            <div class="card bg-info">
                                <img class="card-img-top" src="{{action('OfertaController@getImage',['filename'=>$juego->Imagen])}}" alt="Juego {{$juego->nombre}}" width="100%" height="350px;"  style="opacity:1;"  >
                                <div class="card-body">
                                    <h5 class="card-title ">{{$juego->nombre}}</h5>
                                    <p>Genero: {{$juego->Genero}}</p>
                                    <p>Precio Original: <strike> {{$juego->Precio}} € </strike></p>
                                    <p>Precio Oferta: {{$juego->PrecioOferta}} €</p>
                                    <p>Fecha Inicio: {{$juego->fechaIni}}</p>
                                    <p>Fecha Fin: {{$juego->fechaFin}}</p>
                                </div>
                            </div>
                        </a><span class="text-secondary">{{$cont++}}</span>
                    </div>
                    

                @endforeach
                @if($cont==0)
                    <div class="col-md-3"></div>
                    <div class="col-md-6 justify-content-between" >
                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                            No hay ofertas registradas
                        </div>
                    </div>
                    <div class="col-md-3"></div>
                @endif
                <span class="text-secondary">{{$cont=0}}</span> <!--para que el contador se ponga a 0 otra vez-->
            </div>
        </div>
    </div>
    <div class="row mb-5 mt-2">
    <div class="col-md-1 mt-2 mb-3 pb-5"></div>
@stop