@extends('index')
@section('content')

    <div class="container mb-5">
            <h3 class="text-center mt-5 mb-5 text-info">Modificar Usuario</h3>
                <form action="{{action('UserController@update',['id'=>$usuario->id])}}" method="POST" enctype="multipart/form-data" style="height: 600px">
                    @if (count($errors) > 0)
                        <div class="alert alert-danger">
                            <p>Errores al insertar datos:</p>
                            <ul>
                                @foreach ($errors->all() as $message)
                                    <li>{{ $message }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <input type="hidden" name="_method" value="PUT">
                    {{csrf_field()}}
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Nombre:</label>
                            <input type="text" class="form-control" id="Nombre" name="Nombre" value="{{$usuario->Nombre}}">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Apellidos:</label>
                            <input type="text" class="form-control" id="Apellidos" name="Apellidos" value="{{$usuario->Apellidos}}">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Nombre de usuario:</label>
                            <input type="text" class="form-control" id="Nick" name="Nick" value="{{$usuario->Nick}}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Fecha de nacimiento:</label>
                            <input type="date" class="form-control" id="fecha" name="fecha" value="{{$usuario->fecha}}">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Email:</label>
                            <input type="email" class="form-control" id="email" name="email" value="{{$usuario->email}}">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Contraseña:</label>
                            <input type="password" class="form-control" id="password" name="password" value="{{$usuario->password}}">
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-center">
                        <button type="submit" name="submit" class="btn btn-info mt-5">Modificar Usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop