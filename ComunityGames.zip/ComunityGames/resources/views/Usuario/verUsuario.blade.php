@extends('index')
@section('content')

    <div class="container-fluid mb-5 pb-5" >

        @if (session()->has('status'))
            <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                {{session('status')}}
            </div>
        @endif

        <div class="row d-flex justify-content-center">

            <div class="col-sm-5 p-3 mt-3">
                <table class="table text-center">
                    <thead >
                        <tr>
                            <th scope="col" colspan="2"><h3 class="pb-4 pt-2 text-dark"> {{auth()->user()->Nick}}</h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="table-info">
                            <td>Nombre:</td>
                            <td>{{$usuario->Nombre}}</td>
                        </tr>
                        <tr>
                            <td>Apellidos:</td>
                            <td> {{$usuario->Apellidos}}</td>
                        </tr>
                        <tr class="table-info">
                            <td>Fecha de Nacimiento:</td>
                            <td>{{$usuario->fecha}}</td>
                        </tr>
                        <tr>
                            <td>Correo electronico:</td>
                            <td>{{$usuario->email}}</td>
                        </tr>
                        <tr>
                            <td colspan="2" class="table-info">
                                <a href="{{ action('UserController@editarUsuario', ['id' => $usuario->id] ) }}" class="btn btn-dark">Modificar tu usuario</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

@stop