<?php $__env->startSection('content'); ?>
    <div class="container-fluid" >

        <?php if(session()->has('status')): ?>
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo e(session('status')); ?>

                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        <?php endif; ?>

        <div class="row">
            <p class="col mt-3 text-warning"><a href="<?php echo e(URL::previous()); ?>"><button type="button" class="btn btn-warning text-white"><i class="fas fa-angle-double-left"></i></button></a></p>
        </div>

        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
        <div class="col-md-7 mt-2 mb-3 pb-5 mr-2" max-height="700px">
            <img src="<?php echo e(action('OfertaController@getImage',['filename'=>$juegos->Imagen])); ?>" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
        </div>

        <div class="col-md-3 mb-5 ml-4 pb-5 text-center">
            <table class="table ">
                <thead >
                    <tr>
                        <th scope="col" colspan="2"><h3 class="pb-42pt-2 text-secondary"><?php echo e($juegos->nombre); ?></h3></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="table-secondary">
                        <td>Genero:</td>
                        <td><?php echo e($juegos->Genero); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Desarrollador:</td>
                        <td><?php echo e($juegos->Desarrollador); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Editor:</td>
                        <td><?php echo e($juegos->Editor); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio Original:</td>
                        <td><strike><?php echo e($juegos->Precio); ?> €</strike></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio Oferta:</td>
                        <td><?php echo e($juegos->PrecioOferta); ?> €</td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Gameplay:</td>
                        <td><a class="nav-link text-warning" href="<?php echo e($juegos->Video); ?>"><i class="fab fa-youtube" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Enlace:</td>
                        <td><a class="nav-link text-warning" href="<?php echo e($juegos->Enlace); ?>"><i class="fab fa-steam" style="font-size:30px"></i></a></td>
                    </tr>

                    <tr>
                        <td>
                            <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->Rol=='admin'): ?>
                                        <a href="<?php echo e(action('OfertaController@editarOferta', ['id' => $juegos->id] )); ?>" class="btn btn-warning">Modificar oferta</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->Rol=='admin'): ?>
                                        <a href="<?php echo e(action('OfertaController@borrarOferta', ['id' => $juegos->id] )); ?>" class="btn btn-danger">Eliminar oferta</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>

                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Oferta/verUnaOferta.blade.php ENDPATH**/ ?>