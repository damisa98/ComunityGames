<?php $__env->startSection('content'); ?>
    <div class="container-fluid" >

        <?php if(session()->has('status')): ?>
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo e(session('status')); ?>

                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <img src="<?php echo e(action('JuegoController@getImage',['filename'=>$juegos->Imagen])); ?>" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
            </div>
            <div class="col-md-6 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <form action="<?php echo e(action('ComentarioController@insertarComentario',['id'=>$juegos->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="comentario"><?php echo e(__('Comentario:')); ?></label>
                            <textarea class="form-control <?php if ($errors->has('Descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Descripcion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="Descripcion" rows="7" name="Descripcion" placeholder="Comentario del juego" autocomplete="Descripcion" autofocus required></textarea>
                            <?php if ($errors->has('Descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Descripcion'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <button type="submit" name="submit" class="btn btn-info">Añadir Comentario</button>
                        </div>                        
                    </form>
                </div>
            </div>
        </div>
    
        <div class="row ">
            <table class="table text-center">
                <thead >
                    <tr>
                        <th scope="col" colspan="2"><h3 class="pb-42pt-2 text-dark">Comentarios</h3></th>
                    </tr>
                </thead>
                <tbody>
                <?php if($existe=='true'): ?>
                    <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-secondary">
                            <td>Comentario de: <?php echo e($comentario->Nick); ?></td>
                            <td><?php echo e($comentario->Descripcion); ?></td>
                        </tr>
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->user()->Rol=='admin' || auth()->user()->id=='<?php echo e($usuariocoment->UsuarioID); ?>'): ?>
                                <tr>
                                    <td><a href="<?php echo e(action('ComentarioController@borrarComentario', ['id' => $comentario->id] )); ?>" class="btn btn-danger">Eliminar comentario</a></td>
                                    <td><a href="<?php echo e(action('ComentarioController@editarComentario', ['id' => $comentario->id,'juegoid' =>$juegos->id ] )); ?>" class="btn btn-warning">Modificar comentario</a></td>
                                </tr>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Comentario/VerUnComentario.blade.php ENDPATH**/ ?>