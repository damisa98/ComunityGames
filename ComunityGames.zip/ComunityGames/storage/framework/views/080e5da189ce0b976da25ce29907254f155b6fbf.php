<?php $__env->startSection('content'); ?>

    <div class="container mb-5">
            <h3 class="text-center mt-5 mb-5 text-info">Modificar Usuario</h3>
                <form action="<?php echo e(action('UserController@update',['id'=>$usuario->id])); ?>" method="POST" enctype="multipart/form-data" style="height: 600px">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <p>Errores al insertar datos:</p>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($message); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <input type="hidden" name="_method" value="PUT">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Nombre:</label>
                            <input type="text" class="form-control" id="Nombre" name="Nombre" value="<?php echo e($usuario->Nombre); ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Apellidos:</label>
                            <input type="text" class="form-control" id="Apellidos" name="Apellidos" value="<?php echo e($usuario->Apellidos); ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Nombre de usuario:</label>
                            <input type="text" class="form-control" id="Nick" name="Nick" value="<?php echo e($usuario->Nick); ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Fecha de nacimiento:</label>
                            <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo e($usuario->fecha); ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Email:</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($usuario->email); ?>">
                        </div>
                        <div class="form-group col-md-4">
                            <label>Contraseña:</label>
                            <input type="password" class="form-control" id="password" name="password" value="<?php echo e($usuario->password); ?>">
                        </div>
                    </div>
                    <div class="form-row d-flex justify-content-center">
                        <button type="submit" name="submit" class="btn btn-info mt-5">Modificar Usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Usuario/editarUsuario.blade.php ENDPATH**/ ?>