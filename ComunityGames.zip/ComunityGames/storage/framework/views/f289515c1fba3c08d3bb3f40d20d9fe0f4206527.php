<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

            <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver Comentarios de los Juegos</h3>

            <?php if(session()->has('status')): ?>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8 justify-content-between" >
                    <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo e(session('status')); ?>

                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            <?php endif; ?>

            <div class="row" style="min-height:400px">
                <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                        <a href="<?php echo e(action('ComentarioController@getShow', ['id' => $juego->id])); ?>" style="text-decoration: none; color:black;">
                            <div class="card bg-info">
                                <img class="card-img-top" src="<?php echo e(action('OfertaController@getImage',['filename'=>$juego->Imagen])); ?>" alt="Juego <?php echo e($juego->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                <div class="card-body">
                                    <h5 class="card-title "><?php echo e($juego->nombre); ?></h5>
                                    <p>Genero: <?php echo e($juego->Genero); ?></p>
                                </div>
                            </div>
                        </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                    </div>
                    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <div class="row mb-5 mt-2">
    <div class="col-md-1 mt-2 mb-3 pb-5"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Comentario/verComentarios.blade.php ENDPATH**/ ?>