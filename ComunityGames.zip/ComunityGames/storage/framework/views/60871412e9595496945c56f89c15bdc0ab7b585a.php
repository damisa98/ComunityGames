<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->Rol=='admin'): ?>
                <div class="col-md-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(action('OfertaController@insertarOferta')); ?>"><button type="button" class="btn btn-dark ">Insertar Oferta</button></a>
                        </li>
                    </ul>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
        <div class="col-md-12">

            <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver las ofertas de los Juegos</h3>

            <?php if(session()->has('status')): ?>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8 justify-content-between" >
                    <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php echo e(session('status')); ?>

                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            <?php endif; ?>

            <div class="row" style="min-height:400px">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                        <a href="<?php echo e(action('OfertaController@getShow', ['id' => $juego->id])); ?>" style="text-decoration: none; color:black;">
                            <div class="card bg-info">
                                <img class="card-img-top" src="<?php echo e(action('OfertaController@getImage',['filename'=>$juego->Imagen])); ?>" alt="Juego <?php echo e($juego->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                <div class="card-body">
                                    <h5 class="card-title "><?php echo e($juego->nombre); ?></h5>
                                    <p>Genero: <?php echo e($juego->Genero); ?></p>
                                    <p>Precio Original: <strike> <?php echo e($juego->Precio); ?> € </strike></p>
                                    <p>Precio Oferta: <?php echo e($juego->PrecioOferta); ?> €</p>
                                </div>
                            </div>
                        </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                    </div>
                    

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($cont==0): ?>
                    <div class="col-md-3"></div>
                    <div class="col-md-6 justify-content-between" >
                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                            No hay ofertas registradas
                        </div>
                    </div>
                    <div class="col-md-3"></div>
                <?php endif; ?>
                <span class="text-secondary"><?php echo e($cont=0); ?></span> <!--para que el contador se ponga a 0 otra vez-->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Oferta/VerOfertas.blade.php ENDPATH**/ ?>