<?php $__env->startSection('content'); ?>
    <div class="container-fluid" >

        <?php if(session()->has('status')): ?>
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo e(session('status')); ?>

                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <img src="<?php echo e(action('JuegoController@getImage',['filename'=>$juegos->Imagen])); ?>" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
            </div>
            <div class="col-md-6 mt-2 mb-3 pb-5 mr-2" max-height="700px">
                <form action="<?php echo e(action('ComentarioController@updateComentario',['id'=>$comentarios->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="comentario"><?php echo e(__('Comentario:')); ?></label>
                            <textarea class="form-control <?php if ($errors->has('Descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Descripcion'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="Descripcion" rows="7" name="Descripcion" placeholder="Comentario del juego" autocomplete="Descripcion" autofocus required><?php echo e($comentarios->Descripcion); ?></textarea>
                            <?php if ($errors->has('Descripcion')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Descripcion'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            <button type="submit" name="submit" class="btn btn-info">Añadir Comentario</button>
                        </div>    
                    </form>
                </div>
            </div>
        </div>
        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Comentario/editarComentario.blade.php ENDPATH**/ ?>