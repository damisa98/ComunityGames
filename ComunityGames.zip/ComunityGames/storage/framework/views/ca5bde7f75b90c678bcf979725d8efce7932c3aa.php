<?php $__env->startSection('content'); ?>

<div class="container mb-5">
    <h3 class="text-center mt-5 mb-5 text-info">Editar Juego</h3>
        <form action="<?php echo e(action('OfertaController@updateOferta',['id'=>$ofertas->id])); ?>" method="POST" enctype="multipart/form-data" style="height: 600px">

            <?php echo e(csrf_field()); ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="JuegoID"><?php echo e(__('Juego:')); ?></label>
                    <select class="form-control" id="JuegoID" class="form-control <?php if ($errors->has('JuegoID')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('JuegoID'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="JuegoID" value="<?php echo e($ofertas->JuegoID); ?>"  autocomplete="JuegoID" required>
                        <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($juego->id); ?>"><?php echo e($juego->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('JuegoID')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('JuegoID'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="PrecioOferta"><?php echo e(__('Precio Oferta:')); ?></label>
                    <input type="number" class="form-control" id="PrecioOferta" class="form-control <?php if ($errors->has('PrecioOferta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('PrecioOferta'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="PrecioOferta" value="<?php echo e($ofertas->PrecioOferta); ?>" autocomplete="PrecioOferta" autofocus placeholder="PrecioOferta" required>
                    <?php if ($errors->has('PrecioOferta')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('PrecioOferta'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Modificar Juego</button>
            </div>
            
        </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Oferta/editarOferta.blade.php ENDPATH**/ ?>