<?php $__env->startSection('content'); ?>
    <div class="container-fluid" >

        <?php if(session()->has('status')): ?>
        <div class="row">
            <div class="col-md-2 "></div>
            <div class="col-md-8 justify-content-between " >
                <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo e(session('status')); ?>

                </div>
            </div>
            <div class="col-md-2 mb-5"></div>
        </div>
        <?php endif; ?>

        <div class="row">
            <p class="col mt-3 text-warning"><a href="<?php echo e(URL::previous()); ?>"><button type="button" class="btn btn-dark text-white"><i class="fas fa-angle-double-left">Atras</i></button></a></p>
            <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if($jugado!='false'): ?>
                        <p class="col mt-3 text-warning"><a href="<?php echo e(action('JugadoController@insertarJugado',['id'=>$juegos->id])); ?>"><button type="button" class="btn btn-dark text-white"><i class="fas fa-heart"> Insertar a Favorito</i></button></a></p>
                        <div class="form-group col-md-4">
                            <form action="<?php echo e(action('JugadoController@insertarJugadoValorar',['id'=>$juegos->id])); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>    
                                <label>Valorar:</label>
                                <input type="number" class="form-control" id="Valoración" class="form-control <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Valoración" value="0" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                <div class="form-row d-flex justify-content-center">
                                    <button type="submit" name="submit" class="btn btn-info">Insertar Valoración</button>
                                </div>
                            </form>
                        </div>
                    <?php else: ?>
                        <?php if($favorito!='false'): ?>
                            <p class="col mt-3 text-warning"><a href="<?php echo e(action('JugadoController@editarJugado',['id'=>$juegos->id,'fav'=>1])); ?>"><button type="button" class="btn btn-dark text-white"><i class="fas fa-heart"> Añadir a Favorito</i></button></a></p>
                        <?php else: ?>
                            <p class="col mt-3 text-warning"><a href="<?php echo e(action('JugadoController@editarJugado',['id'=>$juegos->id,'fav'=>0])); ?>"><button type="button" class="btn btn-dark text-white"><i class="far fa-heart"> Quitar de Favorito</i></button></a></p>
                        <?php endif; ?>
                        <?php if($valoracion!='false'): ?>
                            <div class="form-group col-md-4">
                                <form action="<?php echo e(action('JugadoController@editarJuegoVal',['id'=>$juegos->id])); ?>" method="POST" enctype="multipart/form-data" >
                                    <?php echo e(csrf_field()); ?>    
                                    <label>Valorar:</label>
                                    <input type="number" class="form-control" id="Valoración" class="form-control <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Valoración" value="<?php echo e($juegos->Enlace); ?>" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                    <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <div class="form-row d-flex justify-content-center">
                                        <button type="submit" name="submit" class="btn btn-info">Añadir Valoración</button>
                                    </div>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="form-group col-md-4">
                                <form action="<?php echo e(action('JugadoController@editarJuegoVal',['id'=>$juegos->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>    
                                    <label>Editar Valoración:</label>
                                    <input type="number" class="form-control" id="Valoración" class="form-control <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Valoración" value="<?php echo e($juegos->Enlace); ?>" autocomplete="Valoración" placeholder="Valoración del juego" required>
                                    <?php if ($errors->has('Valoración')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Valoración'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    <div class="form-row d-flex justify-content-center">
                                        <button type="submit" name="submit" class="btn btn-info">Editar Valoración</button>
                                    </div>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="row mb-5 mt-2">
        <div class="col-md-1 mt-2 mb-3 pb-5"></div>
        <div class="col-md-7 mt-2 mb-3 pb-5 mr-2" max-height="700px">
            <img src="<?php echo e(action('JuegoController@getImage',['filename'=>$juegos->Imagen])); ?>" class="img-fluid" alt="imagen del juego" width="100%" style="max-height:600px" style="opacity:1"  >
        </div>

        <div class="col-md-3 mb-5 ml-4 pb-5 text-center">
            <table class="table ">
                <thead >
                    <tr>
                        <th scope="col" colspan="2"><h3 class="pb-42pt-2 text-dark"><?php echo e($juegos->nombre); ?></h3></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="table-secondary">
                        <td>Genero:</td>
                        <td><?php echo e($juegos->Genero); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Desarrollador:</td>
                        <td><?php echo e($juegos->Desarrollador); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Editor:</td>
                        <td><?php echo e($juegos->Editor); ?></td>
                    </tr>
                    <tr class="table-secondary">
                        <td>Precio:</td>
                        <td><?php echo e($juegos->Precio); ?> €</td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Gameplay:</td>
                        <td><a class="nav-link text-warning" href="<?php echo e($juegos->Video); ?>"><i class="fab fa-youtube" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr class="table-secondary">
                        <td >Enlace:</td>
                        <td><a class="nav-link text-warning" href="<?php echo e($juegos->Enlace); ?>"><i class="fab fa-steam" style="font-size:30px"></i></a></td>
                    </tr>
                    <tr>
                        <td>
                            <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->Rol=='admin'): ?>
                                        <a href="<?php echo e(action('JuegoController@editarJuego', ['id' => $juegos->id] )); ?>" class="btn btn-warning">Modificar juego</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(auth()->user()->Rol=='admin'): ?>
                                        <?php if($existe!='false'): ?>
                                            <a href="<?php echo e(action('JuegoController@borrarJuego', ['id' => $juegos->id] )); ?>" class="btn btn-danger">Eliminar juego</a>
                                        <?php else: ?>
                                            <a href="#" class="btn btn-danger">Oferta Existente</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                        </td>
                    </tr>

                </tbody>
            </table>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Juego/verUnJuego.blade.php ENDPATH**/ ?>