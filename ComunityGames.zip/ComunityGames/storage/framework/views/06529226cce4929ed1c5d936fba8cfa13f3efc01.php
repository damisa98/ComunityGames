<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-5"  style="height: 800px">
        <div class="row mt-3">
            <div class="col-12 ">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" style="color:black" id="home-tab" data-toggle="tab" href="#VerJuegos" role="tab" aria-controls="VerJuegos" aria-selected="true">Ver Juegos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Recomendados" role="tab" aria-controls="Recomendados" aria-selected="false">Recomendados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Juegados" role="tab" aria-controls="Juegados" aria-selected="false">Jugados</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:black" id="profile-tab" data-toggle="tab" href="#Favoritos" role="tab" aria-controls="Favoritos" aria-selected="false">Favoritos</a>
                    </li>
                    <?php if(Route::has('login')): ?>          <!--Si no está logueado ni es admin no muestra el botón-->
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->Rol=='admin'): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(action('JuegoController@insertarJuego')); ?>"><button type="button" class="btn btn-dark ">Insertar Juego</button></a>
                            </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>


                <!-- VerJuegos -->

                <div class="tab-content mb-5 " id="myTabContent">

                    <div class="tab-pane fade show active pb-5 mb-5" id="VerJuegos" role="tabpanel" aria-labelledby="VerJuegos-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4  mt-5 mb-5 text-dark">Ver Todos los Juegos</h3>

                                <?php if(session()->has('status')): ?>
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8 justify-content-between" >
                                        <div class="alert alert-success alert-dismissable  mt-4 mb-2 text-center" role="alert">
                                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>
                                <?php endif; ?>

                                <div class="row" style="min-height:400px">
                                    <?php $__currentLoopData = $juegos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $juego): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-sm-6 mb-4 text-center">
                                            <a href="<?php echo e(action('JuegoController@getShow', ['id' => $juego->id])); ?>" style="text-decoration: none; color:black;">
                                                <div class="card bg-info">
                                                    <img class="card-img-top" src="<?php echo e(action('JuegoController@getImage',['filename'=>$juego->Imagen])); ?>" alt="Juego <?php echo e($juego->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                                    <div class="card-body">
                                                        <h5 class="card-title "><?php echo e($juego->nombre); ?></h5>
                                                        <p>Genero: <?php echo e($juego->Genero); ?></p>
                                                        <p>Precio: <?php echo e($juego->Precio); ?> €</p>
                                                    </div>
                                                </div>
                                            </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                                        </div>
                                        

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cont==0): ?>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-6 justify-content-between" >
                                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                            No hay juegos registrados
                                        </div>
                                    </div>
                                    <div class="col-md-3"></div>
                                    <?php endif; ?>
                                    <span class="text-secondary"><?php echo e($cont=0); ?></span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>
                            </div>
                        </div>
                    </div>


                        <!-- Recomendados -->

                    <div class="tab-pane fade pb-5 mb-5" id="Recomendados" role="tabpanel" aria-labelledby="Recomendados-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Recomendados</h3>

                                <?php if(session()->has('status')): ?>
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="row" style="min-height:400px">
                                    <?php $__currentLoopData = $recomendados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recomendado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-sm-6 mb-4 text-center">
                                            <a href="<?php echo e(action('JuegoController@getShow', ['id' => $recomendado->id])); ?>" style="text-decoration: none; color:black;">
                                                    <div class="card bg-info">
                                                        <img class="card-img-top" src="<?php echo e(action('JuegoController@getImage',['filename'=>$recomendado->Imagen])); ?>" alt="Juego Recomendado <?php echo e($recomendado->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                                        <div class="card-body">
                                                            <h5 class="card-title "><?php echo e($recomendado->nombre); ?></h5>
                                                            <p>Genero: <?php echo e($recomendado->Genero); ?></p>
                                                            <p>Precio: <?php echo e($recomendado->Precio); ?> €</p>
                                                        </div>
                                                    </div>
                                            </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                                        </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cont==0): ?>
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6 justify-content-between" >
                                            <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                                No hay juegos recomendados registrados
                                            </div>
                                        </div>
                                        <div class="col-md-3"></div>
                                        <?php endif; ?>
                                        <span class="text-secondary"><?php echo e($cont=0); ?></span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>

                            </div>
                        </div>
                    </div>

                        <!-- Jugados -->

                    <div class="tab-pane fade pb-5 mb-5" id="Juegados" role="tabpanel" aria-labelledby="Juegados-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Jugados</h3>
                                <?php if(session()->has('status')): ?>
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="row"  style="min-height:400px">
                                    <?php $__currentLoopData = $jugados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Route::has('login')): ?>
                                            <?php if(auth()->guard()->check()): ?>
                                                <?php if($jugado->UsuarioID==auth()->user()->id): ?>

                                                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                                                        <a href="<?php echo e(action('JuegoController@getShow', ['id' => $jugado->id])); ?>" style="text-decoration: none; color:black;">
                                                            <div class="card bg-info">
                                                                <img class="card-img-top" src="<?php echo e(action('JuegoController@getImage',['filename'=>$jugado->Imagen])); ?>" alt="Juego jugado <?php echo e($jugado->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                                                <div class="card-body">
                                                                <h5 class="card-title "><?php echo e($jugado->nombre); ?></h5>
                                                                    <p>Genero: <?php echo e($jugado->Genero); ?></p>
                                                                    <p>Precio: <?php echo e($jugado->Precio); ?> €</p>
                                                                </div>
                                                            </div>
                                                        </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cont==0): ?>
                                    <div class="col-md-3"></div>
                                    <div class="col-md-6 justify-content-between" >
                                        <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                            No hay juegos jugados registrados
                                        </div>
                                    </div>
                                    <div class="col-md-3"></div>
                                    <?php endif; ?>
                                    <span class="text-secondary"><?php echo e($cont=0); ?></span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>


                            </div>
                        </div>
                    </div>

                        <!-- Favoritos -->

                    <div class="tab-pane fade pb-5 mb-5" id="Favoritos" role="tabpanel" aria-labelledby="Favoritos-tab">
                        <div class="row">
                            <div class="col-md-12">

                                <h3 class="text-center m-4 mt-5 mb-5 text-dark">Juegos Favoritos</h3>

                                <?php if(session()->has('status')): ?>
                                    <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="row" style="min-height:400px">
                                    <?php $__currentLoopData = $favoritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(Route::has('login')): ?>
                                            <?php if(auth()->guard()->check()): ?>
                                                <?php if($favorito->UsuarioID==auth()->user()->id): ?>

                                                    <div class="col-md-3 col-sm-6 mb-4 text-center">
                                                        <a href="<?php echo e(action('JuegoController@getShow', ['id' => $favorito->id])); ?>" style="text-decoration: none; color:black;">
                                                                <div class="card bg-info">
                                                                    <img class="card-img-top" src="<?php echo e(action('JuegoController@getImage',['filename'=>$favorito->Imagen])); ?>" alt="Juego en favorito <?php echo e($favorito->nombre); ?>" width="100%" height="350px;"  style="opacity:1;"  >
                                                                    <div class="card-body">
                                                                        <h5 class="card-title "><?php echo e($favorito->nombre); ?></h5>
                                                                        <p>Genero: <?php echo e($favorito->Genero); ?></p>
                                                                        <p>Precio: <?php echo e($favorito->Precio); ?> €</p>
                                                                    </div>
                                                                </div>
                                                        </a><span class="text-secondary"><?php echo e($cont++); ?></span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cont==0): ?>
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6 justify-content-between" >
                                            <div class="alert alert-secondary alert-dismissable p-5 mt-4 mb-2 text-center" role="alert">
                                                No hay juegos en favoritos
                                            </div>
                                        </div>
                                        <div class="col-md-3"></div>
                                    <?php endif; ?>
                                    <span class="text-secondary"><?php echo e($cont=0); ?></span> <!--para que el contador se ponga a 0 otra vez-->
                                </div>

                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Juego/verJuegos.blade.php ENDPATH**/ ?>