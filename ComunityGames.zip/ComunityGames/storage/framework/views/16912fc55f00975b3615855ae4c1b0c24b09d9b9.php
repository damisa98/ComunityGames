<?php $__env->startSection('content'); ?>

    <div class="container-fluid mb-5 pb-5" >

        <?php if(session()->has('status')): ?>
            <div class="alert alert-success alert-dismissable mt-4 mb-2" role="alert">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <div class="row d-flex justify-content-center">

            <div class="col-sm-5 p-3 mt-3">
                <table class="table text-center">
                    <thead >
                        <tr>
                            <th scope="col" colspan="2"><h3 class="pb-4 pt-2 text-dark"> <?php echo e(auth()->user()->Nick); ?></h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="table-info">
                            <td>Nombre:</td>
                            <td><?php echo e($usuario->Nombre); ?></td>
                        </tr>
                        <tr>
                            <td>Apellidos:</td>
                            <td> <?php echo e($usuario->Apellidos); ?></td>
                        </tr>
                        <tr class="table-info">
                            <td>Fecha de Nacimiento:</td>
                            <td><?php echo e($usuario->fecha); ?></td>
                        </tr>
                        <tr>
                            <td>Correo electronico:</td>
                            <td><?php echo e($usuario->email); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="table-info">
                                <a href="<?php echo e(action('UserController@editarUsuario', ['id' => $usuario->id] )); ?>" class="btn btn-dark">Modificar tu usuario</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Usuario/verUsuario.blade.php ENDPATH**/ ?>