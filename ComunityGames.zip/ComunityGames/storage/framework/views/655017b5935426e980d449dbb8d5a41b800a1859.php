<header class="text-center bg-dark">
  <h1 id="cabecera" class="text-success"> Comunity Games <i class="fas fa-gamepad"></i></h1>

  <nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <a class="navbar-brand text-dark" href="<?php echo e(action('JuegoController@index')); ?>"> <i class="fas fa-gamepad"></i></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">

            <li class="nav-item Home">
                <a class="nav-link text-dark" href="<?php echo e(action('JuegoController@index')); ?>">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(action('JuegoController@juegos')); ?>">Juegos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(action('OfertaController@VerOfertas')); ?>">Ofertas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(action('ComentarioController@verComentarios')); ?>">Comentario</a>
            </li>
        </ul>

      <ul class="navbar-nav navbar-right">

              <?php if(Route::has('login')): ?>
                  <?php if(auth()->guard()->check()): ?>
                      <li class="nav-item">
                          <a class="nav-link text-dark" href="<?php echo e(action('UserController@verUsuario', ['id' => auth()->user()->id])); ?>"> <?php echo e(auth()->user()->Nombre); ?> <?php echo e(auth()->user()->Apellidos); ?> </a>         <!--muestra el nombre de usuario si no está logueado-->
                      </li>
                      <li class="nav-item">
                          <form action="<?php echo e(url('/logout')); ?>" method="POST" style="display:inline">
                              <?php echo e(csrf_field()); ?>

                              <button type="submit" class="btn btn-link nav-link text-dark" style="display:inline;cursor:pointer">
                                  Cerrar Sesión
                                  <i class="fas fa-door-closed"></i>
                              </button>
                          </form>
                      </li>
                  <?php else: ?>
                  <li>
                      <a href="<?php echo e(route('login')); ?>"  style="display:inline" style="text-decoration: none">

                          <button type="submit" class="btn btn-link nav-link text-dark" style="display:inline;cursor:pointer">
                              Loguearse
                              <i class="fas fa-user-astronaut"></i>
                          </button>
                      </a>
                  </li>

                  <?php endif; ?>
              <?php endif; ?>
      </ul>

    </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/includes/header.blade.php ENDPATH**/ ?>