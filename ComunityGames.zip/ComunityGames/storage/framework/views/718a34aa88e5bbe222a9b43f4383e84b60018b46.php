<?php $__env->startSection('content'); ?>

<div class="container mb-5">
    <h3 class="text-center mt-5 mb-5 text-info">Editar Juego</h3>
        <form action="<?php echo e(action('JuegoController@updateJuego',['id'=>$juegos->id])); ?>" method="POST" enctype="multipart/form-data" style="height: 600px">

            <?php echo e(csrf_field()); ?>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="nombre"><?php echo e(__('Nombre:')); ?></label>
                    <input type="text" class="form-control" id="nombre" class="form-control <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nombre" value="<?php echo e($juegos->nombre); ?>"  placeholder="Nombre del juego" autocomplete="nombre" autofocus required>
                    <?php if ($errors->has('nombre')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nombre'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="genero"><?php echo e(__('Genero:')); ?></label>
                    <input type="text" class="form-control" id="genero" class="form-control <?php if ($errors->has('genero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('genero'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="genero" value="<?php echo e($juegos->Genero); ?>"  autocomplete="genero" autofocus placeholder="Genero del juego" required>
                    <?php if ($errors->has('Genero')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Genero'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="desarrollador">Desarrollador:</label>
                    <input type="text" class="form-control" id="desarrollador" class="form-control <?php if ($errors->has('desarrollador')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desarrollador'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="desarrollador" value="<?php echo e($juegos->Desarrollador); ?>"  autocomplete="desarrollador" placeholder="Desarrollador del juego"required>
                    <?php if ($errors->has('Desarrollador')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Desarrollador'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group col-md-4">
                    <label for="editor">Editor:</label>
                    <input type="text" class="form-control" id="editor" class="form-control <?php if ($errors->has('editor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('editor'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="editor" value="<?php echo e($juegos->Editor); ?>"  autocomplete="editor" placeholder="Editor del juego"required>
                    <?php if ($errors->has('Editor')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Editor'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group col-md-4">
                    <label>Precio:</label>
                    <input type="text" class="form-control" id="precio" class="form-control <?php if ($errors->has('precio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="precio" value="<?php echo e($juegos->Precio); ?>"  autocomplete="precio"placeholder="Precio del juego" required>
                    <?php if ($errors->has('precio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('precio'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>Imagen:</label>
                    <input type="file" class="form-control" id="imagen" class="form-control <?php if ($errors->has('imagen')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('imagen'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="imagen" value="<?php echo e($juegos->Imagen); ?>"   autocomplete="imagen" >
                    <?php if ($errors->has('imagen')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('imagen'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="form-group col-md-4">
                    <label>Video:</label>
                    <input type="text" class="form-control" id="video" class="form-control <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="video" value="<?php echo e($juegos->Video); ?>" autocomplete="video" placeholder="Link del juego" required>
                    <?php if ($errors->has('video')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('video'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group col-md-4">
                    <label>Enlace del juego:</label>
                    <input type="text" class="form-control" id="enlace" class="form-control <?php if ($errors->has('enlace')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('enlace'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="enlace" value="<?php echo e($juegos->Enlace); ?>" autocomplete="enlace" placeholder="enlace del juego" required>
                    <?php if ($errors->has('enlace')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('enlace'); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
            </div>
            <div class="form-row d-flex justify-content-center">
                <button type="submit" name="submit" class="btn btn-info">Modificar Juego</button>
            </div>
        </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\ComunityGames\resources\views/Juego/editarJuego.blade.php ENDPATH**/ ?>