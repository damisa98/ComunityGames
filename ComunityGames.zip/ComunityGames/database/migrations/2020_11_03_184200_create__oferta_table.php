<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOfertaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Ofertas', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->float('PrecioOferta',8,2);
            $table->unsignedBigInteger('JuegoID')->unique();
            $table->foreign('JuegoID')->references('id')->on('Juegos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Ofertas');
    }
}
