<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComentarioTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Comentarios', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('UsuarioID');
            $table->unsignedBigInteger('JuegoID');
            $table->string('Descripcion',500);
            $table->foreign('UsuarioID')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('JuegoID')->references('id')->on('Juegos')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('Comentarios');
    }
}
