<?php

use Illuminate\Database\Seeder;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use App\User;

class usersSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert(array
            (array(
                'rol' => 'admin',
                'nombre' => 'admin',
                'apellidos' => 'admin admin',
                'nick'  => 'admin',
                'fecha' => '1998-05-26',
                'email' => 'admin@admin.com',
                'password' => bcrypt('admin'),    //PARA GUARDAR LA CONTRASEÑA ENCRIPTADA
            ),
                array(
                'rol' => 'user',
                'nombre' => 'user',
                'apellidos' => 'user user',
                'nick'  => 'user',
                'fecha' => '1998-05-26',
                'email' => 'user@user.com',
                'password' => bcrypt('user'),    //PARA GUARDAR LA CONTRASEÑA ENCRIPTADA

            ))
        );
    }
}
