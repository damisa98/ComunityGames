<?php

use Illuminate\Database\Seeder;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use App\Juego;

class JuegoSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('juegos')->insert(array(
            array(
            'nombre' => 'Atlas',
            'Genero'  => 'Supervivencia',
            'Desarrollador'  => '3dJuegos',
            'Editor' => '3dJuegos',
            'Precio' => '30',
            'Imagen'  => 'atlas.jpg',
            'Video' => 'https://www.youtube.com/watch?v=F6FH48FI-E0',
            'Enlace' => 'https://store.steampowered.com/app/834910/ATLAS/',
            ),
            array(
                'nombre' => 'SAO',
                'Genero'  => 'MMORPG',
                'Desarrollador'  => 'inteer',
                'Editor' => 'inteer',
                'Precio' => '17',
                'Imagen'  => 'SAO.jpg',
                'Video' => 'https://www.youtube.com/watch?v=OsLY7DXWsF4',
                'Enlace' => 'https://store.steampowered.com/app/1009290/SWORD_ART_ONLINE_Alicization_Lycoris/',
                )
        ));

    }
}
