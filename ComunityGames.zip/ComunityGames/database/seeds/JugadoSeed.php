<?php

use Illuminate\Database\Seeder;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;     //tres clases importadas para trabajar con imágenes
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Auth\Middleware\Authenticate;
use App\Jugado;

class JugadoSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('jugados')->insert(array(
            array(
            'usuarioId' => 1,
            'JuegoID' => 1,
            'Favorito'  => 1,
            'Valoración'  => 8,
            )
        ));
    }
}
